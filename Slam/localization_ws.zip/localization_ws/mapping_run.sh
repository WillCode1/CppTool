#!/bin/sh
./devel/lib/localization/mapping_node --lidar_odometry_file="/home/luffy/work/data/KITTI_VELODYNE/final_class/gps.txt" --result_map_file="/home/luffy/work/data/KITTI_VELODYNE/final_class/result_map.pcd"
